export class USyncUser {
    withId(id: any): this;
    id: any;
    withLid(lid: any): this;
    lid: any;
    withPhone(phone: any): this;
    phone: any;
    withUsername(username: any): this;
    username: any;
    withUsernameKey(usernameKey: any): this;
    usernameKey: any;
    withType(type: any): this;
    type: any;
    withPersonaId(personaId: any): this;
    personaId: any;
    withPictureId(pictureId: any): this;
    pictureId: any;
    withVerifiedNameSerial(serial: any): this;
    verifiedNameSerial: any;
    withBusinessProfileTag(tag: any): this;
    businessProfileTag: any;
    withSidelistDelete(del?: boolean): this;
    sidelistDelete: boolean;
}
