export class USyncDeviceProtocol {
    name: string;
    getQueryElement(): {
        tag: string;
        attrs: {
            version: string;
        };
    };
    getUserElement(user: any): {
        tag: string;
        attrs: {
            phash: any;
            ts: any;
            expectedTs: any;
        };
    };
    parser(node: any): {
        deviceList: {
            id: number;
            keyIndex: number;
            isHosted: boolean;
        }[];
        keyIndex: {
            timestamp: number;
            signedKeyIndex: any;
            expectedTimestamp: number;
        };
    };
}
